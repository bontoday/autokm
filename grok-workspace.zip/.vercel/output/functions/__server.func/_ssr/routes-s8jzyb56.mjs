import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pencil, c as ClipboardList, d as Bike, i as Plus, l as Car, o as LayoutDashboard, r as Trash2, s as Droplets, t as Truck, u as Bus } from "../_libs/lucide-react.mjs";
import { n as format, t as es } from "../_libs/date-fns.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as Area, c as Tooltip, i as XAxis, n as BarChart, o as Bar, r as YAxis, s as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-s8jzyb56.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var kmFmt = new Intl.NumberFormat("es-PE", { maximumFractionDigits: 0 });
var moneyFmt = new Intl.NumberFormat("es-PE", {
	style: "currency",
	currency: "PEN",
	maximumFractionDigits: 0
});
function formatKm(n) {
	return `${kmFmt.format(Math.round(n))} km`;
}
function formatNumber(n) {
	return kmFmt.format(Math.round(n));
}
function formatMoney(n) {
	return moneyFmt.format(Math.round(n));
}
function toISODate(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function todayISO(now = /* @__PURE__ */ new Date()) {
	return toISODate(now);
}
function daysAgo(n, now = /* @__PURE__ */ new Date()) {
	return toISODate(new Date(now.getFullYear(), now.getMonth(), now.getDate() - n));
}
function parseLocalDate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y || 1970, (m || 1) - 1, d || 1);
}
function formatDay(iso) {
	return format(parseLocalDate(iso), "d MMM", { locale: es });
}
function formatTodayLabel(now = /* @__PURE__ */ new Date()) {
	return format(now, "EEEE d MMM", { locale: es });
}
function inPeriod(iso, period, now = /* @__PURE__ */ new Date()) {
	if (period === "all") return true;
	const d = parseLocalDate(iso);
	const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
	if (period === "month") return d >= new Date(now.getFullYear(), now.getMonth(), 1) && d <= end;
	return d >= new Date(now.getFullYear(), now.getMonth(), now.getDate() - 29) && d <= end;
}
var TYPE_LABEL = {
	camion: "Camión",
	van: "Van",
	bus: "Bus",
	auto: "Auto",
	moto: "Moto"
};
var PERIOD_LABEL = {
	month: "Este mes",
	"30d": "30 días",
	all: "Todo"
};
var OIL_LABEL = {
	ok: "Al día",
	soon: "Por vencer",
	overdue: "Vencido",
	missing: "Sin registro"
};
function deltaMap(vehicles, entries) {
	const map = /* @__PURE__ */ new Map();
	for (const vehicle of vehicles) {
		const mine = entries.filter((entry) => entry.vehicleId === vehicle.id).sort((a, b) => a.odometer - b.odometer || a.date.localeCompare(b.date));
		let prev = vehicle.openingKm;
		for (const entry of mine) {
			map.set(entry.id, Math.max(0, entry.odometer - prev));
			if (entry.odometer > prev) prev = entry.odometer;
		}
	}
	return map;
}
function currentKm(vehicle, entries, oils) {
	let max = vehicle.openingKm;
	for (const entry of entries) if (entry.vehicleId === vehicle.id && entry.odometer > max) max = entry.odometer;
	for (const oil of oils) if (oil.vehicleId === vehicle.id && oil.km > max) max = oil.km;
	return max;
}
function lastOil(vehicleId, oils) {
	let best = null;
	for (const oil of oils) {
		if (oil.vehicleId !== vehicleId) continue;
		if (!best || oil.km > best.km || oil.km === best.km && oil.date > best.date) best = oil;
	}
	return best;
}
function oilSnapshot(vehicle, km, oils) {
	const last = lastOil(vehicle.id, oils);
	if (!last || vehicle.oilIntervalKm <= 0) return {
		status: "missing",
		remaining: 0,
		dueAt: km,
		used: 0,
		ratio: 0,
		last
	};
	const dueAt = last.km + vehicle.oilIntervalKm;
	const remaining = dueAt - km;
	const used = Math.max(0, km - last.km);
	const ratio = used / vehicle.oilIntervalKm;
	const soonLimit = Math.max(500, vehicle.oilIntervalKm * .15);
	let status = "ok";
	if (remaining <= 0) status = "overdue";
	else if (remaining <= soonLimit) status = "soon";
	return {
		status,
		remaining,
		dueAt,
		used,
		ratio,
		last
	};
}
function build(spec, now = /* @__PURE__ */ new Date()) {
	let km = spec.openingKm;
	const entries = [];
	const oils = [];
	spec.events.forEach((event, index) => {
		if (event.kind === "trip") {
			km += event.delta;
			entries.push({
				id: `${spec.id}-t${index}`,
				vehicleId: spec.id,
				date: daysAgo(event.daysAgo, now),
				odometer: km,
				deltaKm: event.delta,
				route: event.route,
				driver: spec.driver,
				notes: event.notes ?? ""
			});
			return;
		}
		oils.push({
			id: `${spec.id}-o${index}`,
			vehicleId: spec.id,
			date: daysAgo(event.daysAgo, now),
			km,
			cost: event.cost,
			oilType: event.oilType,
			workshop: event.workshop,
			notes: event.notes ?? ""
		});
	});
	return {
		vehicle: {
			id: spec.id,
			plate: spec.plate,
			alias: spec.alias,
			type: spec.type,
			driver: spec.driver,
			oilIntervalKm: spec.oilIntervalKm,
			openingKm: spec.openingKm,
			active: true
		},
		entries,
		oils
	};
}
var SPECS = [
	{
		id: "v-ate",
		plate: "ABC-412",
		alias: "Ruta Ate",
		type: "camion",
		driver: "Luis Quispe",
		oilIntervalKm: 5e3,
		openingKm: 171400,
		events: [
			{
				kind: "oil",
				daysAgo: 48,
				cost: 380,
				oilType: "15W-40",
				workshop: "Taller San Luis"
			},
			{
				kind: "trip",
				daysAgo: 40,
				delta: 780,
				route: "Lima – Huacho"
			},
			{
				kind: "trip",
				daysAgo: 33,
				delta: 910,
				route: "CD Ate – Mega Plaza"
			},
			{
				kind: "trip",
				daysAgo: 26,
				delta: 640,
				route: "Lima – Cañete",
				notes: "Retorno con carga parcial"
			},
			{
				kind: "trip",
				daysAgo: 19,
				delta: 860,
				route: "Ate – Callao"
			},
			{
				kind: "trip",
				daysAgo: 12,
				delta: 720,
				route: "Ruta norte – Ancón"
			},
			{
				kind: "trip",
				daysAgo: 8,
				delta: 800,
				route: "Ate – Santa Anita"
			},
			{
				kind: "trip",
				daysAgo: 5,
				delta: 690,
				route: "Reparto diurno – SJL"
			},
			{
				kind: "trip",
				daysAgo: 1,
				delta: 540,
				route: "Reparto nocturno – La Victoria"
			}
		]
	},
	{
		id: "v-centro",
		plate: "B7K-208",
		alias: "Reparto Centro",
		type: "van",
		driver: "Rosa Huamán",
		oilIntervalKm: 8e3,
		openingKm: 47800,
		events: [
			{
				kind: "oil",
				daysAgo: 40,
				cost: 210,
				oilType: "10W-40",
				workshop: "Lubricentro Breña"
			},
			{
				kind: "trip",
				daysAgo: 26,
				delta: 900,
				route: "Miraflores – San Isidro"
			},
			{
				kind: "trip",
				daysAgo: 20,
				delta: 1100,
				route: "Centro – Magdalena"
			},
			{
				kind: "trip",
				daysAgo: 14,
				delta: 980,
				route: "Breña – Pueblo Libre"
			},
			{
				kind: "trip",
				daysAgo: 9,
				delta: 860,
				route: "Cercado – Rímac"
			},
			{
				kind: "trip",
				daysAgo: 4,
				delta: 1240,
				route: "Reparto express – Surquillo"
			},
			{
				kind: "trip",
				daysAgo: 2,
				delta: 1020,
				route: "Centro – Barranco"
			},
			{
				kind: "trip",
				daysAgo: 1,
				delta: 1e3,
				route: "Última milla – Lince"
			}
		]
	},
	{
		id: "v-norte",
		plate: "CXP-551",
		alias: "Corredor Norte",
		type: "bus",
		driver: "José Delgado",
		oilIntervalKm: 1e4,
		openingKm: 120400,
		events: [
			{
				kind: "trip",
				daysAgo: 30,
				delta: 1800,
				route: "Patio – Ancón"
			},
			{
				kind: "trip",
				daysAgo: 22,
				delta: 1700,
				route: "Corredor – Los Olivos"
			},
			{
				kind: "trip",
				daysAgo: 16,
				delta: 1900,
				route: "Independencia – Centro"
			},
			{
				kind: "trip",
				daysAgo: 9,
				delta: 1400,
				route: "Turno mañana – Comas"
			},
			{
				kind: "trip",
				daysAgo: 6,
				delta: 1400,
				route: "Turno tarde – Comas"
			},
			{
				kind: "oil",
				daysAgo: 6,
				cost: 460,
				oilType: "15W-40",
				workshop: "Patio Norte",
				notes: "Filtro incluido"
			},
			{
				kind: "trip",
				daysAgo: 3,
				delta: 900,
				route: "Corredor – Puente Piedra"
			},
			{
				kind: "trip",
				daysAgo: 1,
				delta: 700,
				route: "Refuerzo – Carabayllo"
			}
		]
	},
	{
		id: "v-frio",
		plate: "D4M-019",
		alias: "Callao Frío",
		type: "camion",
		driver: "Ana Paredes",
		oilIntervalKm: 5e3,
		openingKm: 21e4,
		events: [
			{
				kind: "trip",
				daysAgo: 36,
				delta: 1500,
				route: "Callao – Villa El Salvador"
			},
			{
				kind: "trip",
				daysAgo: 28,
				delta: 1400,
				route: "Cadena de frío – Ventanilla"
			},
			{
				kind: "trip",
				daysAgo: 21,
				delta: 1600,
				route: "Callao – Ate"
			},
			{
				kind: "trip",
				daysAgo: 14,
				delta: 1200,
				route: "Muelle – almacén"
			},
			{
				kind: "trip",
				daysAgo: 9,
				delta: 800,
				route: "Despacho – Santa Anita"
			},
			{
				kind: "oil",
				daysAgo: 9,
				cost: 390,
				oilType: "15W-40",
				workshop: "Frío Service Callao"
			},
			{
				kind: "trip",
				daysAgo: 6,
				delta: 900,
				route: "Callao – Chorrillos"
			},
			{
				kind: "trip",
				daysAgo: 3,
				delta: 1100,
				route: "Ruta refrigerada – Asia"
			},
			{
				kind: "trip",
				daysAgo: 1,
				delta: 700,
				route: "Retorno vacío – Callao"
			}
		]
	},
	{
		id: "v-super",
		plate: "EQR-883",
		alias: "Supervisión",
		type: "auto",
		driver: "Carla Ríos",
		oilIntervalKm: 7e3,
		openingKm: 22e3,
		events: [
			{
				kind: "trip",
				daysAgo: 25,
				delta: 400,
				route: "Base – San Borja"
			},
			{
				kind: "trip",
				daysAgo: 18,
				delta: 380,
				route: "Visita de patio – Ate"
			},
			{
				kind: "trip",
				daysAgo: 10,
				delta: 600,
				route: "Auditoría – Callao"
			},
			{
				kind: "trip",
				daysAgo: 8,
				delta: 450,
				route: "Ruta centro"
			},
			{
				kind: "trip",
				daysAgo: 6,
				delta: 700,
				route: "Seguimiento – Comas"
			},
			{
				kind: "trip",
				daysAgo: 5,
				delta: 900,
				route: "La Molina – Surco"
			},
			{
				kind: "trip",
				daysAgo: 4,
				delta: 850,
				route: "Ingreso a taller"
			},
			{
				kind: "oil",
				daysAgo: 4,
				cost: 150,
				oilType: "5W-30",
				workshop: "Servicio La Molina"
			},
			{
				kind: "trip",
				daysAgo: 2,
				delta: 180,
				route: "Base – oficina"
			},
			{
				kind: "trip",
				daysAgo: 0,
				delta: 140,
				route: "Recorrido corto – Miraflores"
			}
		]
	}
];
function createSeed(now = /* @__PURE__ */ new Date()) {
	const vehicles = [];
	const entries = [];
	const oils = [];
	for (const spec of SPECS) {
		const built = build(spec, now);
		vehicles.push(built.vehicle);
		entries.push(...built.entries);
		oils.push(...built.oils);
	}
	return {
		vehicles,
		entries,
		oils
	};
}
function plateOf(value) {
	return value.toUpperCase().replace(/\s+/g, "").trim();
}
function vehicleError(input, vehicles, ignoreId, withOil = true) {
	const plate = plateOf(input.plate);
	if (plate.length < 5) return "La placa necesita al menos 5 caracteres.";
	if (vehicles.some((v) => v.id !== ignoreId && v.plate === plate)) return "Esa placa ya está registrada.";
	if (input.alias.trim().length < 2) return "Ponle un alias a la unidad.";
	if (input.driver.trim().length < 2) return "Indica el conductor habitual.";
	if (!Number.isFinite(input.oilIntervalKm) || input.oilIntervalKm < 500) return "El intervalo de aceite debe ser de al menos 500 km.";
	if (!Number.isFinite(input.openingKm) || input.openingKm < 0) return "El kilometraje inicial no es válido.";
	if (!withOil) return "";
	if (!Number.isFinite(input.lastOilKm) || input.lastOilKm < 0) return "El km del último aceite no es válido.";
	if (!input.lastOilDate) return "Indica la fecha del último cambio de aceite.";
	if (input.lastOilKm > input.openingKm) return "El último aceite no puede estar por encima del kilometraje inicial.";
	return "";
}
var useFleet = create()(persist((set, get) => ({
	initialized: false,
	tab: "tablero",
	focusVehicleId: null,
	vehicles: [],
	entries: [],
	oils: [],
	setTab: (tab) => set({ tab }),
	openOilFor: (vehicleId) => set({
		tab: "aceite",
		focusVehicleId: vehicleId
	}),
	clearFocus: () => set({ focusVehicleId: null }),
	addVehicle: (input) => {
		const error = vehicleError(input, get().vehicles);
		if (error) return error;
		const id = crypto.randomUUID();
		const vehicle = {
			id,
			plate: plateOf(input.plate),
			alias: input.alias.trim(),
			type: input.type,
			driver: input.driver.trim(),
			oilIntervalKm: Math.round(input.oilIntervalKm),
			openingKm: Math.round(input.openingKm),
			active: input.active
		};
		const oil = {
			id: crypto.randomUUID(),
			vehicleId: id,
			date: input.lastOilDate,
			km: Math.round(input.lastOilKm),
			cost: 0,
			oilType: "Registro inicial",
			workshop: "Registro inicial",
			notes: "Cargado al dar de alta la unidad"
		};
		set((s) => ({
			vehicles: [vehicle, ...s.vehicles],
			oils: [oil, ...s.oils]
		}));
		return "";
	},
	updateVehicle: (id, input) => {
		const current = get().vehicles.find((v) => v.id === id);
		if (!current) return "No se encontró la unidad.";
		const error = vehicleError(input, get().vehicles, id, false);
		if (error) return error;
		const opening = Math.round(input.openingKm);
		const live = currentKm(current, get().entries, get().oils);
		if (opening > live) return `El km inicial no puede superar la lectura actual (${formatKm(live)}). Para subir el odómetro, registra una lectura.`;
		set((s) => ({ vehicles: s.vehicles.map((v) => v.id === id ? {
			...v,
			plate: plateOf(input.plate),
			alias: input.alias.trim(),
			type: input.type,
			driver: input.driver.trim(),
			oilIntervalKm: Math.round(input.oilIntervalKm),
			openingKm: opening,
			active: input.active
		} : v) }));
		return "";
	},
	removeVehicle: (id) => set((s) => ({
		vehicles: s.vehicles.filter((v) => v.id !== id),
		entries: s.entries.filter((e) => e.vehicleId !== id),
		oils: s.oils.filter((o) => o.vehicleId !== id),
		focusVehicleId: s.focusVehicleId === id ? null : s.focusVehicleId
	})),
	addEntry: (input) => {
		const vehicle = get().vehicles.find((v) => v.id === input.vehicleId);
		if (!vehicle) return "Elige una unidad.";
		if (!input.date) return "Indica la fecha.";
		if (!Number.isFinite(input.odometer)) return "La lectura del odómetro no es válida.";
		const odometer = Math.round(input.odometer);
		const reading = currentKm(vehicle, get().entries, get().oils);
		if (odometer <= reading) return `La lectura debe ser mayor a ${formatKm(reading)}.`;
		const route = input.route.trim();
		if (route.length < 2) return "Indica la ruta o el destino.";
		const entry = {
			id: crypto.randomUUID(),
			vehicleId: vehicle.id,
			date: input.date,
			odometer,
			deltaKm: odometer - reading,
			route,
			driver: input.driver.trim() || vehicle.driver,
			notes: input.notes.trim()
		};
		set((s) => ({ entries: [entry, ...s.entries] }));
		return "";
	},
	removeEntry: (id) => set((s) => ({ entries: s.entries.filter((e) => e.id !== id) })),
	addOil: (input) => {
		const vehicle = get().vehicles.find((v) => v.id === input.vehicleId);
		if (!vehicle) return "Elige una unidad.";
		if (!input.date) return "Indica la fecha.";
		if (!Number.isFinite(input.km)) return "El kilometraje del cambio no es válido.";
		const km = Math.round(input.km);
		const previous = lastOil(vehicle.id, get().oils);
		if (previous && km < previous.km) return `El cambio debe ser desde ${formatKm(previous.km)} (último registrado).`;
		if (!Number.isFinite(input.cost) || input.cost < 0) return "El costo no es válido.";
		if (input.oilType.trim().length < 2) return "Indica el tipo de aceite.";
		const reading = currentKm(vehicle, get().entries, get().oils);
		const extra = km > reading ? {
			id: crypto.randomUUID(),
			vehicleId: vehicle.id,
			date: input.date,
			odometer: km,
			deltaKm: km - reading,
			route: "Lectura en cambio de aceite",
			driver: vehicle.driver,
			notes: input.workshop.trim()
		} : null;
		const oil = {
			id: crypto.randomUUID(),
			vehicleId: vehicle.id,
			date: input.date,
			km,
			cost: Math.round(input.cost),
			oilType: input.oilType.trim(),
			workshop: input.workshop.trim(),
			notes: input.notes.trim()
		};
		set((s) => ({
			oils: [oil, ...s.oils],
			entries: extra ? [extra, ...s.entries] : s.entries
		}));
		return "";
	},
	removeOil: (id) => set((s) => ({ oils: s.oils.filter((o) => o.id !== id) })),
	loadDemo: () => {
		set({
			...createSeed(),
			initialized: true,
			tab: "tablero",
			focusVehicleId: null
		});
	},
	clearAll: () => set({
		vehicles: [],
		entries: [],
		oils: [],
		initialized: true,
		focusVehicleId: null
	})
}), {
	name: "anden-flota-v1",
	partialize: (s) => ({
		initialized: s.initialized,
		tab: s.tab,
		vehicles: s.vehicles,
		entries: s.entries,
		oils: s.oils
	})
}));
function ensureFleetReady() {
	if (!useFleet.getState().initialized) useFleet.setState({
		...createSeed(),
		initialized: true
	});
}
function cn(...parts) {
	return parts.filter(Boolean).join(" ");
}
var controlClass = "h-12 w-full rounded-md border border-line bg-surface-2 px-3 text-base text-ink outline-none transition focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/25";
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1.5 block text-sm font-medium text-ink",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-sm text-muted",
				children: hint
			}) : null
		]
	});
}
function ErrorNote({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "rounded-md bg-danger-bg px-3 py-2 text-sm text-accent",
		children
	});
}
function PrimaryButton({ children, type = "button", onClick, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		disabled,
		className: "inline-flex h-12 w-full items-center justify-center gap-2 rounded-md bg-primary px-4 text-base font-semibold text-primary-ink transition active:scale-[0.99] disabled:opacity-50",
		children
	});
}
function GhostButton({ children, onClick, danger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-11 items-center justify-center rounded-md border px-3 text-sm font-medium transition", danger ? "border-accent/30 bg-danger-bg text-accent" : "border-line bg-surface-2 text-ink"),
		children
	});
}
var PILL = {
	ok: "bg-ok-bg text-primary",
	soon: "bg-warn-bg text-warn",
	overdue: "bg-danger-bg text-accent",
	missing: "bg-surface text-muted"
};
function StatusPill({ status, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-7 items-center rounded-full px-2.5 text-xs font-semibold", PILL[status]),
		children: label
	});
}
function Panel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-lg border border-line bg-surface-2 p-4", className),
		children
	});
}
function SectionTitle({ eyebrow, title, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-4",
		children: [
			eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs font-medium tracking-widest text-primary uppercase",
				children: eyebrow
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-xl font-semibold tracking-tight text-ink",
				children: title
			}),
			detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: detail
			}) : null
		]
	});
}
function monday(d) {
	const copy = new Date(d.getFullYear(), d.getMonth(), d.getDate());
	const day = copy.getDay();
	const diff = day === 0 ? 6 : day - 1;
	copy.setDate(copy.getDate() - diff);
	return copy;
}
function fleetMetrics(vehicles, entries, oils, period, now = /* @__PURE__ */ new Date()) {
	const active = vehicles.filter((v) => v.active);
	const activeIds = new Set(active.map((v) => v.id));
	const deltas = deltaMap(vehicles, entries);
	const periodByVehicle = /* @__PURE__ */ new Map();
	let periodKm = 0;
	for (const entry of entries) {
		if (!inPeriod(entry.date, period, now)) continue;
		if (!activeIds.has(entry.vehicleId)) continue;
		const delta = deltas.get(entry.id) ?? 0;
		periodKm += delta;
		periodByVehicle.set(entry.vehicleId, (periodByVehicle.get(entry.vehicleId) ?? 0) + delta);
	}
	const units = active.map((vehicle) => {
		const km = currentKm(vehicle, entries, oils);
		const oil = oilSnapshot(vehicle, km, oils);
		return {
			vehicle,
			km,
			periodKm: periodByVehicle.get(vehicle.id) ?? 0,
			status: oil.status,
			remaining: oil.remaining,
			dueAt: oil.dueAt,
			ratio: oil.ratio
		};
	}).sort((a, b) => b.periodKm - a.periodKm);
	const overdue = units.filter((u) => u.status === "overdue").length;
	const soon = units.filter((u) => u.status === "soon").length;
	const missing = units.filter((u) => u.status === "missing").length;
	const compliance = active.length === 0 ? 0 : (active.length - overdue - missing) / active.length;
	let oilCost = 0;
	for (const oil of oils) {
		if (!inPeriod(oil.date, period, now)) continue;
		if (!activeIds.has(oil.vehicleId)) continue;
		oilCost += oil.cost;
	}
	const topUnit = [...units].sort((a, b) => b.periodKm - a.periodKm)[0];
	const top = topUnit && topUnit.periodKm > 0 ? {
		alias: topUnit.vehicle.alias,
		plate: topUnit.vehicle.plate,
		km: topUnit.periodKm
	} : null;
	const weeks = buildWeeks(entries, activeIds, deltas, now);
	const rank = {
		overdue: 0,
		missing: 1,
		soon: 2,
		ok: 3
	};
	const alerts = units.filter((u) => u.status !== "ok").sort((a, b) => rank[a.status] - rank[b.status] || a.remaining - b.remaining);
	return {
		periodKm,
		avgPerUnit: active.length ? periodKm / active.length : 0,
		compliance,
		overdue,
		soon,
		missing,
		oilCost,
		perThousand: periodKm > 0 ? oilCost / (periodKm / 1e3) : null,
		top,
		units,
		byVehicle: units.map((u) => ({
			label: u.vehicle.plate,
			km: u.periodKm
		})),
		weeks,
		alerts
	};
}
function buildWeeks(entries, activeIds, deltas, now) {
	const start = monday(now);
	start.setDate(start.getDate() - 49);
	const buckets = Array.from({ length: 8 }, (_, i) => {
		const from = new Date(start);
		from.setDate(start.getDate() + i * 7);
		return {
			from,
			km: 0,
			label: format(from, "d MMM", { locale: es })
		};
	});
	for (const entry of entries) {
		if (!activeIds.has(entry.vehicleId)) continue;
		const d = parseLocalDate(entry.date);
		for (let i = 0; i < buckets.length; i++) {
			const from = buckets[i].from;
			const to = i < buckets.length - 1 ? buckets[i + 1].from : new Date(from.getFullYear(), from.getMonth(), from.getDate() + 7);
			if (d >= from && d < to) {
				buckets[i].km += deltas.get(entry.id) ?? 0;
				break;
			}
		}
	}
	return buckets.map(({ label, km }) => ({
		label,
		km
	}));
}
var PERIODS = [
	"month",
	"30d",
	"all"
];
function Dashboard() {
	const vehicles = useFleet((s) => s.vehicles);
	const entries = useFleet((s) => s.entries);
	const oils = useFleet((s) => s.oils);
	const openOilFor = useFleet((s) => s.openOilFor);
	const [period, setPeriod] = (0, import_react.useState)("month");
	const metrics = (0, import_react.useMemo)(() => fleetMetrics(vehicles, entries, oils, period), [
		vehicles,
		entries,
		oils,
		period
	]);
	if (vehicles.filter((v) => v.active).length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "text-base font-semibold",
		children: "Sin unidades activas"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm text-pretty text-muted",
		children: "Da de alta una unidad o restaura el ejemplo para ver kilometraje, aceite y KPIs."
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: PERIODS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPeriod(item),
					className: cn("h-10 rounded-full px-3.5 text-sm font-medium", period === item ? "bg-ink text-surface-2" : "border border-line bg-surface-2 text-muted"),
					children: PERIOD_LABEL[item]
				}, item))
			}),
			metrics.alerts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "border-accent/30 bg-danger-bg/50",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold text-accent",
					children: "Aceite por atender"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: metrics.alerts.map((alert) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => openOilFor(alert.vehicle.id),
						className: "flex w-full items-center justify-between gap-3 rounded-md bg-surface-2 px-3 py-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-mono text-sm font-semibold",
							children: alert.vehicle.plate
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: alert.vehicle.alias
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
								status: alert.status,
								label: OIL_LABEL[alert.status]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-xs text-muted",
								children: alert.status === "missing" ? "Sin cambio cargado" : alert.remaining <= 0 ? `Pasó ${formatKm(Math.abs(alert.remaining))}` : `Faltan ${formatKm(alert.remaining)}`
							})]
						})]
					}) }, alert.vehicle.id))
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "bg-ok-bg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-primary",
					children: "Flota al día con el aceite"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-primary/80",
					children: "Ninguna unidad activa está vencida ni por vencer."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Km recorridos",
						value: formatNumber(metrics.periodKm),
						hint: PERIOD_LABEL[period]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Promedio / unidad",
						value: formatNumber(metrics.avgPerUnit),
						hint: "Solo unidades activas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Cumplimiento",
						value: `${Math.round(metrics.compliance * 100)}%`,
						hint: `${metrics.overdue} vencida${metrics.overdue === 1 ? "" : "s"} · ${metrics.soon} por vencer`,
						tone: metrics.overdue > 0 ? "bad" : "good"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Costo de aceite",
						value: formatMoney(metrics.oilCost),
						hint: metrics.perThousand == null ? "Sin km en el periodo" : `${formatMoney(metrics.perThousand)} / 1.000 km`
					})
				]
			}),
			metrics.top ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Más recorrido:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium text-ink",
						children: [
							metrics.top.alias,
							" (",
							metrics.top.plate,
							")"
						]
					}),
					" ",
					"con ",
					formatKm(metrics.top.km),
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Km por unidad"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-muted",
					children: PERIOD_LABEL[period]
				}),
				metrics.byVehicle.every((row) => row.km === 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-sm text-muted",
					children: "Todavía no hay recorridos en este periodo."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-56",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: metrics.byVehicle,
							margin: {
								top: 8,
								right: 0,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "label",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false,
									interval: 0
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, { suffix: " km" }),
									cursor: { fill: "var(--color-ok-bg)" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "km",
									fill: "var(--color-primary)",
									radius: [
										6,
										6,
										0,
										0
									],
									maxBarSize: 36
								})
							]
						})
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Últimas 8 semanas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-muted",
					children: "Kilómetros de la flota activa, de lunes a domingo."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-52",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: metrics.weeks,
							margin: {
								top: 8,
								right: 4,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "label",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, { suffix: " km" }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: "km",
									stroke: "var(--color-primary)",
									fill: "var(--color-primary)",
									fillOpacity: .18,
									strokeWidth: 2
								})
							]
						})
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Intervalo de aceite"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm text-muted",
					children: "Se vence al cumplir el intervalo de cada unidad. “Por vencer” avisa dentro del 15% o de los últimos 500 km."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-4",
					children: metrics.units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1.5 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-sm font-semibold",
									children: unit.vehicle.plate
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-sm text-muted",
									children: unit.vehicle.alias
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
								status: unit.status,
								label: OIL_LABEL[unit.status]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 overflow-hidden rounded-full bg-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("h-full rounded-full", unit.status === "overdue" || unit.status === "missing" ? "bg-accent" : unit.status === "soon" ? "bg-warn" : "bg-primary"),
								style: { width: `${Math.min(100, Math.max(4, unit.ratio * 100))}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-xs text-muted tabular-nums",
							children: unit.status === "missing" ? "Registra el último cambio" : `${formatKm(unit.km)} · próximo a los ${formatNumber(unit.dueAt)} · cada ${formatNumber(unit.vehicle.oilIntervalKm)}`
						})
					] }, unit.vehicle.id))
				})
			] })
		]
	});
}
function Kpi({ label, value, hint, tone = "neutral" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-surface-2 p-3.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 font-mono text-2xl font-medium tracking-tight tabular-nums", tone === "bad" ? "text-accent" : tone === "good" ? "text-primary" : "text-ink"),
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-pretty text-muted",
				children: hint
			})
		]
	});
}
function ChartTip({ active, payload, label, suffix }) {
	if (!active || !payload?.length) return null;
	const value = payload[0]?.value ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-surface-2 px-2.5 py-1.5 text-xs shadow-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-mono font-medium tabular-nums",
			children: [formatNumber(value), suffix]
		})]
	});
}
function MileageLog() {
	const vehicles = useFleet((s) => s.vehicles);
	const entries = useFleet((s) => s.entries);
	const oils = useFleet((s) => s.oils);
	const addEntry = useFleet((s) => s.addEntry);
	const removeEntry = useFleet((s) => s.removeEntry);
	const active = vehicles.filter((v) => v.active);
	const [vehicleId, setVehicleId] = (0, import_react.useState)(active[0]?.id ?? vehicles[0]?.id ?? "");
	const [date, setDate] = (0, import_react.useState)(todayISO);
	const [odometer, setOdometer] = (0, import_react.useState)("");
	const [route, setRoute] = (0, import_react.useState)("");
	const [driver, setDriver] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const vehicle = vehicles.find((v) => v.id === vehicleId) ?? null;
	const reading = vehicle ? currentKm(vehicle, entries, oils) : 0;
	const typed = Number(odometer);
	const delta = vehicle && Number.isFinite(typed) && typed > reading ? typed - reading : null;
	const oil = vehicle ? oilSnapshot(vehicle, delta != null ? typed : reading, oils) : null;
	const rows = (0, import_react.useMemo)(() => {
		return entries.filter((entry) => filter === "all" || entry.vehicleId === filter).slice().sort((a, b) => a.date === b.date ? b.odometer - a.odometer : b.date.localeCompare(a.date));
	}, [entries, filter]);
	const deltas = (0, import_react.useMemo)(() => deltaMap(vehicles, entries), [vehicles, entries]);
	function onVehicle(id) {
		setVehicleId(id);
		const next = vehicles.find((v) => v.id === id);
		setDriver(next?.driver ?? "");
		setSaved("");
		setError("");
	}
	function submit() {
		const message = addEntry({
			vehicleId,
			date,
			odometer: typed,
			route,
			driver: driver || vehicle?.driver || "",
			notes
		});
		if (message) {
			setError(message);
			setSaved("");
			return;
		}
		setError("");
		setSaved(`Lectura guardada · recorrido ${formatKm(typed - reading)}.`);
		setOdometer("");
		setRoute("");
		setNotes("");
	}
	if (vehicles.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
		title: "Plantilla de kilometraje",
		detail: "Primero da de alta una unidad en la pestaña Unidades."
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			eyebrow: "Plantilla",
			title: "Registro de kilometraje",
			detail: "Una fila por lectura de odómetro. El recorrido se calcula contra la última marca de esa unidad."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Unidad",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: controlClass,
						value: vehicleId,
						onChange: (e) => onVehicle(e.target.value),
						children: vehicles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.id,
							children: [
								item.plate,
								" · ",
								item.alias,
								item.active ? "" : " (fuera de servicio)"
							]
						}, item.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Fecha",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Odómetro (km)",
						hint: vehicle ? `Última lectura: ${formatKm(reading)}` : void 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${controlClass} font-mono tabular-nums`,
							inputMode: "numeric",
							value: odometer,
							placeholder: reading ? String(reading) : "0",
							onChange: (e) => {
								setOdometer(e.target.value.replace(/[^\d]/g, ""));
								setSaved("");
							},
							required: true
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted uppercase",
							children: "Recorrido de esta lectura"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-mono text-2xl font-medium tabular-nums text-ink",
							children: delta == null ? "—" : `+${formatNumber(delta)}`
						}),
						oil && oil.status === "overdue" && delta != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-accent",
							children: "Esta lectura deja el aceite vencido. Programa el cambio."
						}) : null,
						oil && oil.status === "soon" && delta != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-warn",
							children: [
								"Aceite por vencer: faltan ",
								formatKm(oil.remaining),
								"."
							]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ruta o destino",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						value: route,
						placeholder: "Ej. Ate – Callao",
						onChange: (e) => setRoute(e.target.value),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Conductor",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						value: driver || vehicle?.driver || "",
						onChange: (e) => setDriver(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Observaciones",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "min-h-24 w-full rounded-md border border-line bg-surface-2 px-3 py-3 text-base text-ink outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/25",
						value: notes,
						placeholder: "Peaje, carga, incidencia…",
						onChange: (e) => setNotes(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }) : null,
				saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-primary",
					children: saved
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "Registrar lectura"
				})
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: "Bitácora"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: "h-10 max-w-[12rem] rounded-md border border-line bg-surface-2 px-2 text-sm",
				value: filter,
				onChange: (e) => setFilter(e.target.value),
				"aria-label": "Filtrar por unidad",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "all",
					children: "Todas"
				}), vehicles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: item.id,
					children: item.plate
				}, item.id))]
			})]
		}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-6 text-sm text-muted",
			children: "Aún no hay lecturas con este filtro."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col divide-y divide-line",
			children: rows.map((entry) => {
				const owner = vehicles.find((v) => v.id === entry.vehicleId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: formatDay(entry.date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: " · "
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono font-semibold",
										children: owner?.plate ?? "—"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-ink",
								children: entry.route
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [entry.driver, entry.notes ? ` · ${entry.notes}` : ""]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-sm font-semibold text-primary tabular-nums",
								children: ["+", formatNumber(deltas.get(entry.id) ?? entry.deltaKm)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-muted tabular-nums",
								children: formatNumber(entry.odometer)
							}),
							pendingDelete === entry.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-1 text-xs font-semibold text-accent",
								onClick: () => {
									removeEntry(entry.id);
									setPendingDelete(null);
								},
								children: "Confirmar"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-1 inline-flex size-9 items-center justify-center text-muted",
								"aria-label": `Borrar lectura de ${owner?.plate ?? "unidad"}`,
								onClick: () => setPendingDelete(entry.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						]
					})]
				}, entry.id);
			})
		})] })]
	});
}
var OIL_TYPES = [
	"15W-40",
	"10W-40",
	"5W-30",
	"20W-50"
];
function OilPanel() {
	const vehicles = useFleet((s) => s.vehicles);
	const entries = useFleet((s) => s.entries);
	const oils = useFleet((s) => s.oils);
	const focusVehicleId = useFleet((s) => s.focusVehicleId);
	const clearFocus = useFleet((s) => s.clearFocus);
	const addOil = useFleet((s) => s.addOil);
	const removeOil = useFleet((s) => s.removeOil);
	const [vehicleId, setVehicleId] = (0, import_react.useState)(vehicles.find((v) => v.active)?.id ?? vehicles[0]?.id ?? "");
	const [date, setDate] = (0, import_react.useState)(todayISO);
	const [km, setKm] = (0, import_react.useState)("");
	const [cost, setCost] = (0, import_react.useState)("");
	const [oilType, setOilType] = (0, import_react.useState)(OIL_TYPES[0]);
	const [workshop, setWorkshop] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)("");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!focusVehicleId) return;
		setVehicleId(focusVehicleId);
		setSaved("");
		setError("");
		clearFocus();
	}, [focusVehicleId, clearFocus]);
	const vehicle = vehicles.find((v) => v.id === vehicleId) ?? null;
	const reading = vehicle ? currentKm(vehicle, entries, oils) : 0;
	const snap = vehicle ? oilSnapshot(vehicle, reading, oils) : null;
	(0, import_react.useEffect)(() => {
		if (!vehicle) return;
		setKm(String(reading));
	}, [vehicle, reading]);
	const history = (0, import_react.useMemo)(() => {
		return oils.filter((oil) => !vehicle || oil.vehicleId === vehicle.id).slice().sort((a, b) => a.date === b.date ? b.km - a.km : b.date.localeCompare(a.date));
	}, [oils, vehicle]);
	function submit() {
		const message = addOil({
			vehicleId,
			date,
			km: Number(km),
			cost: cost === "" ? 0 : Number(cost),
			oilType,
			workshop,
			notes
		});
		if (message) {
			setError(message);
			setSaved("");
			return;
		}
		setError("");
		setSaved("Cambio de aceite registrado. El próximo intervalo ya quedó recalculado.");
		setCost("");
		setWorkshop("");
		setNotes("");
	}
	if (vehicles.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
		title: "Cambios de aceite",
		detail: "Da de alta una unidad para definir su intervalo."
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			eyebrow: "Plantilla",
			title: "Cambio de aceite",
			detail: "Cada unidad vence al sumar su intervalo sobre el último cambio. El aviso salta en el último 15% o en los 500 km finales."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Unidad",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: controlClass,
						value: vehicleId,
						onChange: (e) => {
							setVehicleId(e.target.value);
							setSaved("");
							setError("");
						},
						children: vehicles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.id,
							children: [
								item.plate,
								" · ",
								item.alias
							]
						}, item.id))
					})
				}),
				vehicle && snap ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-sm font-semibold",
								children: vehicle.plate
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									"Cada ",
									formatNumber(vehicle.oilIntervalKm),
									" km"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
								status: snap.status,
								label: OIL_LABEL[snap.status]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-mono text-2xl font-medium tabular-nums",
							children: snap.status === "missing" ? "Sin base" : snap.remaining <= 0 ? `+${formatNumber(Math.abs(snap.remaining))}` : formatNumber(snap.remaining)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: snap.status === "missing" ? "Registra el cambio de referencia." : snap.remaining <= 0 ? `km vencido · lectura ${formatKm(reading)}` : `km restantes · próximo cambio en ${formatKm(snap.dueAt)}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-2 overflow-hidden rounded-full bg-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("h-full rounded-full", snap.status === "overdue" || snap.status === "missing" ? "bg-accent" : snap.status === "soon" ? "bg-warn" : "bg-primary"),
								style: { width: `${Math.min(100, Math.max(snap.status === "missing" ? 0 : 4, snap.ratio * 100))}%` }
							})
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Fecha del cambio",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Km del cambio",
						hint: "Puedes corregir la lectura del taller",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${controlClass} font-mono tabular-nums`,
							inputMode: "numeric",
							value: km,
							onChange: (e) => setKm(e.target.value.replace(/[^\d]/g, "")),
							required: true
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tipo de aceite",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: controlClass,
							value: oilType,
							onChange: (e) => setOilType(e.target.value),
							children: [OIL_TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: type }, type)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Otro" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Costo (S/)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${controlClass} font-mono tabular-nums`,
							inputMode: "numeric",
							value: cost,
							placeholder: "0",
							onChange: (e) => setCost(e.target.value.replace(/[^\d]/g, ""))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Taller",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						value: workshop,
						placeholder: "Nombre del taller",
						onChange: (e) => setWorkshop(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notas",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						value: notes,
						placeholder: "Filtro, fugas, próximo control…",
						onChange: (e) => setNotes(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }) : null,
				saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-primary",
					children: saved
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "Registrar cambio"
				})
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "mb-2 text-sm font-semibold",
			children: ["Historial ", vehicle ? `· ${vehicle.plate}` : ""]
		}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-6 text-sm text-muted",
			children: "Esta unidad todavía no tiene cambios cargados."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col divide-y divide-line",
			children: history.map((oil) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start gap-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-medium",
						children: [
							formatDay(oil.date),
							" · ",
							oil.oilType
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [oil.workshop || "Sin taller", oil.notes ? ` · ${oil.notes}` : ""]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-sm font-semibold tabular-nums",
							children: formatNumber(oil.km)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: oil.cost > 0 ? formatMoney(oil.cost) : "Sin costo"
						}),
						pendingDelete === oil.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-1 text-xs font-semibold text-accent",
							onClick: () => {
								removeOil(oil.id);
								setPendingDelete(null);
							},
							children: "Confirmar"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-1 inline-flex size-9 items-center justify-center text-muted",
							"aria-label": "Borrar cambio de aceite",
							onClick: () => setPendingDelete(oil.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				})]
			}, oil.id))
		})] })]
	});
}
var TYPES = [
	"camion",
	"van",
	"bus",
	"auto",
	"moto"
];
var ICONS = {
	camion: Truck,
	van: Truck,
	bus: Bus,
	auto: Car,
	moto: Bike
};
var emptyForm = () => ({
	plate: "",
	alias: "",
	type: "camion",
	driver: "",
	oilIntervalKm: 5e3,
	openingKm: 0,
	active: true,
	lastOilKm: 0,
	lastOilDate: todayISO()
});
function Units() {
	const vehicles = useFleet((s) => s.vehicles);
	const entries = useFleet((s) => s.entries);
	const oils = useFleet((s) => s.oils);
	const addVehicle = useFleet((s) => s.addVehicle);
	const updateVehicle = useFleet((s) => s.updateVehicle);
	const removeVehicle = useFleet((s) => s.removeVehicle);
	const loadDemo = useFleet((s) => s.loadDemo);
	const clearAll = useFleet((s) => s.clearAll);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(emptyForm);
	const [error, setError] = (0, import_react.useState)("");
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const [confirmClear, setConfirmClear] = (0, import_react.useState)(false);
	function openNew() {
		setEditing("new");
		setForm(emptyForm());
		setError("");
	}
	function openEdit(vehicle) {
		setEditing(vehicle.id);
		setForm({
			plate: vehicle.plate,
			alias: vehicle.alias,
			type: vehicle.type,
			driver: vehicle.driver,
			oilIntervalKm: vehicle.oilIntervalKm,
			openingKm: vehicle.openingKm,
			active: vehicle.active,
			lastOilKm: 0,
			lastOilDate: todayISO()
		});
		setError("");
	}
	function save() {
		const message = editing === "new" ? addVehicle(form) : editing ? updateVehicle(editing, form) : "Nada que guardar.";
		if (message) {
			setError(message);
			return;
		}
		setEditing(null);
		setError("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						eyebrow: "Flota",
						title: "Unidades",
						detail: "La placa, el conductor y cada cuántos kilómetros toca el aceite."
					})
				}), editing == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: openNew,
					className: "mb-4 inline-flex h-11 shrink-0 items-center gap-1.5 rounded-md bg-primary px-3 text-sm font-semibold text-primary-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Nueva"]
				}) : null]
			}),
			editing != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-4 text-base font-semibold",
				children: editing === "new" ? "Alta de unidad" : "Editar unidad"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					save();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Placa",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${controlClass} font-mono uppercase`,
								value: form.plate,
								onChange: (e) => setForm({
									...form,
									plate: e.target.value.toUpperCase()
								}),
								placeholder: "ABC-123",
								required: true
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Alias",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								value: form.alias,
								onChange: (e) => setForm({
									...form,
									alias: e.target.value
								}),
								placeholder: "Ruta Ate",
								required: true
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tipo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: controlClass,
							value: form.type,
							onChange: (e) => setForm({
								...form,
								type: e.target.value
							}),
							children: TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: type,
								children: TYPE_LABEL[type]
							}, type))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Conductor habitual",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: form.driver,
							onChange: (e) => setForm({
								...form,
								driver: e.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Km inicial",
							hint: "Odómetro al dar de alta",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${controlClass} font-mono tabular-nums`,
								inputMode: "numeric",
								value: form.openingKm ? String(form.openingKm) : "",
								placeholder: "0",
								onChange: (e) => {
									const openingKm = Number(e.target.value.replace(/[^\d]/g, "") || 0);
									setForm((current) => ({
										...current,
										openingKm,
										lastOilKm: editing === "new" && (current.lastOilKm === 0 || current.lastOilKm === current.openingKm) ? openingKm : current.lastOilKm
									}));
								}
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Aceite cada (km)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${controlClass} font-mono tabular-nums`,
								inputMode: "numeric",
								value: String(form.oilIntervalKm),
								onChange: (e) => setForm({
									...form,
									oilIntervalKm: Number(e.target.value.replace(/[^\d]/g, "") || 0)
								})
							})
						})]
					}),
					editing === "new" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Último aceite (km)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${controlClass} font-mono tabular-nums`,
								inputMode: "numeric",
								value: form.lastOilKm ? String(form.lastOilKm) : "",
								placeholder: "0",
								onChange: (e) => setForm({
									...form,
									lastOilKm: Number(e.target.value.replace(/[^\d]/g, "") || 0)
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Fecha de ese cambio",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								type: "date",
								value: form.lastOilDate,
								onChange: (e) => setForm({
									...form,
									lastOilDate: e.target.value
								}),
								required: true
							})
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Los cambios de aceite nuevos se cargan en la pestaña Aceite. Aquí solo ajustas el intervalo."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-12 items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "size-5 accent-primary",
							checked: form.active,
							onChange: (e) => setForm({
								...form,
								active: e.target.checked
							})
						}), "Unidad activa (entra a los KPIs)"]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						type: "submit",
						children: editing === "new" ? "Guardar unidad" : "Actualizar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: () => setEditing(null),
						children: "Cancelar"
					})
				]
			})] }) : null,
			vehicles.length === 0 && editing == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No hay unidades. Crea la primera o carga el ejemplo de Lima."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: loadDemo,
					children: "Cargar ejemplo"
				})
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: vehicles.map((vehicle) => {
					const km = currentKm(vehicle, entries, oils);
					const oil = oilSnapshot(vehicle, km, oils);
					const Icon = ICONS[vehicle.type];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cn("rounded-lg border border-line bg-surface-2 p-4", !vehicle.active && "opacity-70"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 shrink-0 place-items-center rounded-md bg-ok-bg text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-lg font-semibold tracking-wide",
												children: vehicle.plate
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-sm text-ink",
												children: [
													vehicle.alias,
													" · ",
													TYPE_LABEL[vehicle.type]
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-muted",
												children: vehicle.driver
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
										status: vehicle.active ? oil.status : "missing",
										label: vehicle.active ? OIL_LABEL[oil.status] : "Inactiva"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-2 gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Odómetro"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono font-medium tabular-nums",
									children: formatKm(km)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Intervalo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono font-medium tabular-nums",
									children: formatKm(vehicle.oilIntervalKm)
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GhostButton, {
									onClick: () => openEdit(vehicle),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "mr-1.5 size-3.5" }), "Editar"]
								}), confirmId === vehicle.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
									danger: true,
									onClick: () => {
										removeVehicle(vehicle.id);
										setConfirmId(null);
									},
									children: "Confirmar borrado"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
									danger: true,
									onClick: () => setConfirmId(vehicle.id),
									children: "Eliminar"
								})]
							})
						]
					}) }, vehicle.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Datos de esta bitácora"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Se guardan en este dispositivo. El ejemplo trae cinco unidades de Lima para ver los indicadores."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: loadDemo,
						children: "Restaurar ejemplo"
					}), confirmClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						danger: true,
						onClick: () => {
							clearAll();
							setConfirmClear(false);
							setEditing(null);
						},
						children: "Sí, borrar todo"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						danger: true,
						onClick: () => setConfirmClear(true),
						children: "Borrar todo"
					})]
				})
			] })
		]
	});
}
var TABS = [
	{
		id: "tablero",
		label: "Tablero",
		icon: LayoutDashboard
	},
	{
		id: "km",
		label: "Km",
		icon: ClipboardList
	},
	{
		id: "aceite",
		label: "Aceite",
		icon: Droplets
	},
	{
		id: "unidades",
		label: "Unidades",
		icon: Truck
	}
];
function App() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const tab = useFleet((s) => s.tab);
	const setTab = useFleet((s) => s.setTab);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		const finish = () => {
			if (cancel) return;
			ensureFleetReady();
			setReady(true);
		};
		const unsub = useFleet.persist.onFinishHydration(finish);
		if (useFleet.persist.hasHydrated()) finish();
		return () => {
			cancel = true;
			unsub();
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-bg px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid size-12 place-items-center rounded-md bg-primary font-mono text-lg font-semibold text-primary-ink",
					children: "A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-base font-semibold",
					children: "Andén"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Abriendo la bitácora…"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink md:grid md:grid-cols-[15.5rem_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-screen flex-col border-r border-line bg-surface px-4 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex flex-col gap-1",
						"aria-label": "Secciones",
						children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							item,
							active: tab === item.id,
							onClick: () => setTab(item.id)
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto text-xs text-pretty text-muted",
						children: "Kilometraje, aceite por intervalo y KPIs de la flota. Los datos quedan en este navegador."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-10 border-b border-line bg-bg/95 px-4 py-3 backdrop-blur md:static md:border-0 md:bg-transparent md:px-8 md:pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { compact: true })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden items-end justify-between md:flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-primary uppercase",
							children: formatTodayLabel()
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-semibold tracking-tight",
							children: titleFor(tab)
						})] })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto w-full max-w-3xl px-4 pt-4 pb-28 md:px-8 md:pb-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mb-4 text-xl font-semibold tracking-tight md:hidden",
							children: titleFor(tab)
						}),
						tab === "tablero" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {}) : null,
						tab === "km" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MileageLog, {}) : null,
						tab === "aceite" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OilPanel, {}) : null,
						tab === "unidades" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Units, {}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface-2 pb-[env(safe-area-inset-bottom)] md:hidden",
				"aria-label": "Secciones",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-4",
					children: TABS.map((item) => {
						const Icon = item.icon;
						const active = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTab(item.id),
							className: cn("flex h-16 w-full flex-col items-center justify-center gap-1 text-xs font-medium", active ? "text-primary" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.4 : 2
							}), item.label]
						}) }, item.id);
					})
				})
			})
		]
	});
}
function Brand({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-10 place-items-center rounded-md bg-primary font-mono text-base font-semibold text-primary-ink",
			children: "A"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-base leading-none font-semibold tracking-tight",
			children: "Andén"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-muted", compact ? "text-xs" : "mt-1 text-sm"),
			children: "Control de transporte"
		})] })]
	});
}
function NavButton({ item, active, onClick }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-11 items-center gap-2.5 rounded-md px-3 text-sm font-medium", active ? "bg-primary text-primary-ink" : "text-ink hover:bg-surface-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label === "Km" ? "Kilometraje" : item.label]
	});
}
function titleFor(tab) {
	if (tab === "tablero") return "Tablero de flota";
	if (tab === "km") return "Kilometraje";
	if (tab === "aceite") return "Aceite";
	return "Unidades";
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };
