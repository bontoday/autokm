//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-hojXShjx.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Bnxc9IbX.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bnxc9IbX.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bq7D7Nyb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
